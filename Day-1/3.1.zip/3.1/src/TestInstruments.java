

public class TestInstruments {

	public static void main(String[] args) {
		
		Instrument[] arr= {new piano(),new Flute(), new Guitar() };
	    for(int i=0;i<arr.length;i++) {
	    	if(arr[i] instanceof Instrument) {
	    		arr[i].play();
	  

	}

}
}
}