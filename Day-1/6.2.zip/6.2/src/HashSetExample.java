    import java.util.*;  
    class Product {  
    String id;  
    String name;
    public  Product (String id, String name) {  
        this.id = id;  
        this.name = name;  
         }  
  }  
    public class HashSetExample {  
   HashSet<Product> set=new HashSet<Product>();  

	public static void main(String[] args) {  
        HashSet<Product> set=new HashSet<Product>();  
         
        Product p1=new Product("P101","Maruti 800");  
        Product p2=new Product("P102","Maruti Zen");  
        Product p3=new Product("P103","Maruti Dezire"); 
        Product p4=new Product("P104","Maruti Alto"); 
        set.add(p4);
        set.add(p3);  
        set.add(p2);  
        set.add(p1);  
 
        for(Product p:set){  
        System.out.println(p.id+" "+p.name);  
        }  
    }  
}  