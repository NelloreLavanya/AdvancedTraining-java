

public class TestMedicine {
	
	public static void main(String[] args) {
		
		MedicineInfo[] arr = {new Tablet(), new Ointment(), new Syrup() };

		
		int i=(int)(Math.random()*2);
		arr[i].displayLabel();

}
}