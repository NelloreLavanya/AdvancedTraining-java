

public class Ointment implements MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("to used externally ");

	}

}
