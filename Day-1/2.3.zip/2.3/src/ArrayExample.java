
public class ArrayExample {
	
	static int[] sumOfarray(int[] arr) {
	int sum=0;
	for(int i=0;i<=14;i++) {
		sum+=arr[i];
	}
	arr[15]=sum;
	arr[16]=sum/15;
	arr[17]=smallestOfArray(arr);
	return arr;
	
	}
	static int smallestOfArray(int[] arr) {
		int smallest=0;
		for(int i=0;i<=13;i++) {
			if(arr[i]<arr[i+1]) {
				smallest=arr[i];
			}else smallest=arr[i+1];
		}
		return smallest;
	}
	
	

	public static void main(String[] args) {
		
		int[] A= {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		
		A=sumOfarray(A);
		System.out.print("[ ");
		for(int i=0;i<A.length;i++) {
			System.out.print(A[i]+" ");
		}
		System.out.println(" ]");
		
		
	}

}
