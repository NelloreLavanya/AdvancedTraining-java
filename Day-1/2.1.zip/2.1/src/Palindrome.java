import java.util.Scanner;
public class Palindrome {
	
	public static void Palindrome(String input) {
		String s="";
		for(int i=input.length()-1;i>=0;i--) {
			s+=input.charAt(i);
		}
		if(s.equals(input)) {
			System.out.println("Is a palindrome");
		}else System.out.println("Not a palindrome");
	}

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter a word to check");
		String i=sc.nextLine().toUpperCase();
		sc.close();
		System.out.println("Length of the given String "+i.length());
		Palindrome(i);
		
	}

}