import java.util.LinkedList;

public class TestEmployee {
	employee e1=new employee(123, "Mahendra", "atp");
	employee e2=new employee(1234, "Lavanya", "NLR");
	employee e3=new employee(123, "Manju", "ATP");
	LinkedList<employee> list=new LinkedList<employee>();

	public static void main(String[] args) {
		
		TestEmployee t1=new TestEmployee();
		t1.addEmp(t1.list);
		t1.display(t1.list);
		
		
		
		
		
		
	}

	private  void addEmp(LinkedList<employee> list) {
		list.add(e1);
		list.add(e2);
		list.add(e3);
	}
	
	public void display(LinkedList<employee> list) {
		for(employee e:list) {
			System.out.println(e.getEmpNumber()+" "+e.getEmpName()+" "+e.getEmpAddress());
		}
	}
}