import java.util.Scanner;

public class StringManipulation {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("enter a name your wish");
		String s=sc.nextLine().toUpperCase();
		sc.close();
		String temp=s;
	
		do {
			char chr=s.charAt(0);
		    s=s.substring(1, s.length())+chr;
			System.out.println(s);
			
		}while((s.equals(temp))!=true);
		
		

	}

}
