import java.util.ArrayList;
public class Arraylist {
   public static void main(String[] args) {
 
      ArrayList<String> StudentList = new ArrayList<String>();
      StudentList.add("Lavu");
      StudentList.add("Mahi");
      StudentList.add("Vishh");
      StudentList.add("Nithi");
 
      //call contains method to check if different strings are present in ArrayList 
      System.out.println("ArrayList contains ('Lavu Nithi'): "
                                           +StudentList.contains("Lavu Nithi"));
      System.out.println("ArrayList contains ('Mahi'): "
                                             +StudentList.contains("Mahi"));
      System.out.println("ArrayList contains ('Lavu'): "
                                          +StudentList.contains("Lavu"));
      System.out.println("ArrayList contains ('Vishh'): "
                                           +StudentList.contains("Vishh"));
   }
}