package com.example1;
public class Rectangle {
	
	double Length;
	double Breadth;
	
	public Rectangle(double length, double breadth) {
		super();
		Length = length;
		Breadth = breadth;
	}
	
	public double getLength() {
		return Length;
	}
	public void setLength(double length) {
		Length = length;
	}
	public double getBreadth() {
		return Breadth;
	}
	public void setBreadth(double breadth) {
		Breadth = breadth;
	}
	
	public void infoOfRectangle() {
		double area =Length*Breadth;
		System.out.println("Length of Rectangle is "+ Length+" units");
		System.out.println("Breadth of Rectangle is "+ Breadth+" units");
		System.out.println("Perimeter of Rectangle is "+ 2*(Length+Breadth)+" units");
		System.out.println("area of the Rectangle is "+ area+" sq.units");
	}
	

	
}