
import java.util.Scanner;
public class TestRectangle {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the length of Rectangle");
		double L=sc.nextDouble();
		System.out.println("Enter the width of Rectangle");
		double W=sc.nextDouble();
		sc.close();
		
		Rectangle r1=new Rectangle(L,W);
		r1.infoOfRectangle();
	}

}